<template>
  <div class="container mt-5">
    <h2>Door Lock Control</h2>
    <div class="form-check form-switch">
      <input class="form-check-input" type="checkbox" id="doorLockSwitch" v-model="doorLockStatus" role="switch">
      <label class="form-check-label" for="doorLockSwitch">{{ doorLockStatus ? 'ON' : 'OFF' }}</label>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Door',
  data() {
    return {
      doorLockStatus: false
    }
  }
}
</script>

<style scoped>
/* Add any custom styles here */
</style>