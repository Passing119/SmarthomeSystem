<template>
    <div class="container mt-5">
      <h2>Light Control</h2>
      <div class="row">
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header text-center">
              <h3>Select Lights</h3>
            </div>
            <div class="card-body">
              <div v-for="light in lights" :key="light.id" class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  :id="`light-${light.id}`"
                  :value="light.id"
                  v-model="selectedLights"
                  :disabled="mode !== 'custom'"
                >
                <label class="form-check-label" :for="`light-${light.id}`">
                  Light {{ light.id }}
                </label>
              </div>
            </div>
          </div>
        </div>
  
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header text-center">
              <h3>Select Mode</h3>
            </div>
            <div class="card-body">
              <select class="form-select" v-model="mode" @change="updateMode">
                <option value="custom">Custom</option>
                <option value="bright">Bright</option>
                <option value="sleep">Sleep</option>
                <option value="normal">Normal</option>
              </select>
            </div>
          </div>
        </div>
      </div>
  
      <button class="btn btn-primary d-block mx-auto" @click="setLightSettings">Set Settings</button>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Light',
    data() {
      return {
        lights: [
          { id: 1 },
          { id: 2 },
          { id: 3 },
          { id: 4 },
          { id: 5 }
        ],
        selectedLights: [],
        mode: 'custom', // 默认模式为自定义
      };
    },
    methods: {
      updateMode() {
        switch (this.mode) {
          case 'bright':
            this.selectedLights = this.lights.map(light => light.id);
            break;
          case 'sleep':
            this.selectedLights = [1];
            break;
          case 'normal':
            this.selectedLights = [1, 2, 3];
            break;
          case 'custom':
            this.selectedLights = [];
            break;
        }
      },
      setLightSettings() {
        const selectedLightsString = this.selectedLights.join(', ');
        alert(`Settings:
        Mode: ${this.mode}
        Selected Lights: ${selectedLightsString}`);
      }
    }
  }
  </script>
  
  <style scoped>
  .card {
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  .card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #e3e6f0;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
  
  .card-body {
    padding: 20px;
  }
  
  .btn-primary {
    background-color: #007bff;
    border-color: #007bff;
  }
  
  .btn-primary:hover {
    background-color: #0056b3;
    border-color: #004085;
  }
  </style>