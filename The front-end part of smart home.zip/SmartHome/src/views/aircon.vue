<template>
  <div class="container mt-5">
    <h2>Air Conditioner Control</h2>
    <div class="row">
      <div class="col-md-6 mb-4">
        <div class="card">
          <div class="card-header text-center">
            <h3>Turn/Off</h3>
          </div>
          <div class="card-body">
            <div class="form-check form-switch mb-3">
              <input class="form-check-input" type="checkbox" id="airconSwitch" v-model="airconStatus" role="switch">
              <label class="form-check-label" for="airconSwitch">{{ airconStatus ? 'ON' : 'OFF' }}</label>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card">
          <div class="card-header text-center">
            <h3>Mode</h3>
          </div>
          <div class="card-body">
            <select class="form-select" v-model="mode">
              <option value="cooling">Cooling</option>
              <option value="heating">Heating</option>
              <option value="auto">Auto</option>
            </select>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card">
          <div class="card-header text-center">
            <h3>Temperature (°C)</h3>
          </div>
          <div class="card-body d-flex align-items-center">
            <button class="btn btn-secondary me-2" @click="decreaseTemperature">-</button>
            <span class="fs-4">{{ temperature }}</span>
            <button class="btn btn-secondary ms-2" @click="increaseTemperature">+</button>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card">
          <div class="card-header text-center">
            <h3>Fan Speed</h3>
          </div>
          <div class="card-body">
            <select class="form-select" v-model="fanSpeed">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card">
          <div class="card-header text-center">
            <h3>Swing</h3>
          </div>
          <div class="card-body">
            <select class="form-select" v-model="swing">
              <option value="auto">Auto</option>
              <option value="up">Up</option>
              <option value="middle">Middle</option>
              <option value="down">Down</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <button class="btn btn-primary d-block mx-auto" @click="setSettings">Set Settings</button>
  </div>
</template>

<script>
export default {
  name: 'Aircon',
  data() {
    return {
      airconStatus: false,
      mode: 'auto', // 默认模式为 Auto
      temperature: 22, // 默认温度为 22°C
      fanSpeed: 'medium', // 默认风速为 Medium
      swing: 'auto', // 默认风向为 Auto
      minTemperature: 16, // 最低温度
      maxTemperature: 30, // 最高温度
    };
  },
  methods: {
    setSettings() {
      alert(`Settings:
      Air Conditioner: ${this.airconStatus ? 'ON' : 'OFF'}
      Mode: ${this.mode}
      Temperature: ${this.temperature}°C
      Fan Speed: ${this.fanSpeed}
      Swing: ${this.swing}`);
    },
    increaseTemperature() {
      if (this.temperature < this.maxTemperature) {
        this.temperature += 1;
      }
    },
    decreaseTemperature() {
      if (this.temperature > this.minTemperature) {
        this.temperature -= 1;
      }
    }
  }
}
</script>

<style scoped>
.card {
  border: 1px solid #0d0d0d;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.card-header {
  background-color: #74a6d8;
  border-bottom: 1px solid #e3e6f0;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.card-body {
  padding: 20px;
}

.btn-secondary {
  background-color: #6c757d;
  border-color: #6c757d;
}

.btn-secondary:hover {
  background-color: #5a6268;
  border-color: #545b62;
}
</style>