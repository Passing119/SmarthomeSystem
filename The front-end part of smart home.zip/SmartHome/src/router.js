import { createRouter, createWebHistory } from 'vue-router'
import Aircon from './views/aircon.vue'
import Light from './views/light.vue'
import Door from './views/door.vue'

const routes = [
    {
        path: '/aircon',
        name: 'Aircon',
        component: Aircon
    },
    {
        path: '/light',
        name: 'Light',
        component: Light
    },
    {
        path: '/door',
        name: 'Door',
        component: Door
    }
]

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes
})

export default router