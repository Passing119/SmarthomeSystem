<template>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Smart Home</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav nav-tabs mr-auto">
                <li class="nav-item">
                    <router-link to="/aircon" class="nav-link">Air Conditioner</router-link>
                </li>
                <li class="nav-item">
                    <router-link to="/light" class="nav-link">Light</router-link>
                </li>
                <li class="nav-item">
                    <router-link to="/door" class="nav-link">Door Lock</router-link>
                </li>
            </ul>
        </div>
    </nav>
</template>

<script>
export default {
    name: 'Header'
}
</script>

<style scoped>
/* Add any custom styles here */
</style>